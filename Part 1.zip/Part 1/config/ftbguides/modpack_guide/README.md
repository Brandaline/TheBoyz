# Welcome adventurer! 
___
![Modpack's logo](q.png)
___
Here you will find some info about this pack as well as some tips and tricks.

Please read carefully as it can be crucial for your survival.

Be sure to read info about:
- Scaling health
- Quality tools
- Level up system